function varargout = selfwork1(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @selfwork1_OpeningFcn, ...
                   'gui_OutputFcn',  @selfwork1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function selfwork1_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;


guidata(hObject, handles);



% --- Outputs from this function are returned to the command line.
function varargout = selfwork1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 global im
    [file, path] = uigetfile({'*.jpg;*.png;*.bmp'}, 'Select an image');
    if isequal(file,0)
        return;
    end
    im = imread(fullfile(path, file));
    axes(handles.axes1);
    imshow(im);


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, ~, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
   % Анхны зураг хадгалагдсан эсэхийг шалгана
global im 
imshow(im) 
    
    
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
msgbox('Thanks for using image processing tool')
pause(1);
close();
close();


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    global im
    if size(im, 3) == 1
        im = cat(3, im, im, im);
    end
    sliderValue = get(hObject, 'Value');
    brightnessAdjustment = -50 + 100 * sliderValue;
    brightImage = double(im) + brightnessAdjustment;
    brightImage = uint8(min(max(brightImage, 0), 255));
    axes(handles.axes2);
    imshow(brightImage);


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    global im
    if size(im, 3) == 1
        im = cat(3, im, im, im);  
    end
    sliderValue = get(hObject, 'Value');
    minAmount = 0;
    maxAmount = 2.0;
    sharpenAmount = minAmount + (maxAmount - minAmount) * sliderValue;
    imgDouble = double(im);
    h = fspecial('unsharp', sharpenAmount);  
    sharpImage = imfilter(imgDouble, h, 'replicate'); 
    sharpImage = uint8(min(max(sharpImage, 0), 255));
    axes(handles.axes2);
    imshow(sharpImage);






% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end





% --- Executes on slider movement.
function slider8_Callback(hObject, eventdata, handles)
% hObject    handle to slider8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    % "im" глобал хувьсагч
    global im
    sliderValue = get(hObject, 'Value');
    minBlueStrength = 0.2;
    blueStrength = minBlueStrength + (1 - minBlueStrength) * sliderValue;
    blueImage = zeros(size(im), 'uint8');
    blueChannel = double(im(:, :, 3)) * blueStrength;
    blueChannel = uint8(min(max(blueChannel, 0), 255));
    blueImage(:, :, 3) = blueChannel;
    blueImage(:, :, 1) = 0; % Red
    blueImage(:, :, 2) = 0; % Green
    axes(handles.axes2);
    imshow(blueImage);


% --- Executes during object creation, after setting all properties.
function slider8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end




% --- Executes on button press in pushbutton61.
function pushbutton61_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton61 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
    if size(im, 3) == 3  
        grayImage = rgb2gray(im);
    else
        grayImage = im;
    end
    axes(handles.axes2);
    imshow(grayImage);


 




% --- Executes on slider movement.
function slider11_Callback(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    global im
    if size(im, 3) == 1
        im = cat(3, im, im, im);
    end
    sliderValue = get(hObject, 'Value');
    minRedStrength = 0.2;
    redStrength = minRedStrength + (1 - minRedStrength) * sliderValue
    redImage = zeros(size(im), 'uint8');
    redChannel = double(im(:, :, 1)) * redStrength;
    redChannel = uint8(min(max(redChannel, 0), 255));
    redImage(:, :, 1) = redChannel;
    redImage(:, :, 2) = 0;
    redImage(:, :, 3) = 0;
    axes(handles.axes2);
    imshow(redImage);


% --- Executes during object creation, after setting all properties.
function slider11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider12_Callback(hObject, eventdata, handles)
% hObject    handle to slider12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    global im
    if size(im, 3) == 1
        im = cat(3, im, im, im);
    end
    sliderValue = get(hObject, 'Value');
    minGreenStrength = 0.2;
    greenStrength = minGreenStrength + (1 - minGreenStrength) * sliderValue;
    greenImage = zeros(size(im), 'uint8');
    greenChannel = double(im(:, :, 2)) * greenStrength;
    greenChannel = uint8(min(max(greenChannel, 0), 255));
    greenImage(:, :, 2) = greenChannel;
    greenImage(:, :, 1) = 0; % Red
    greenImage(:, :, 3) = 0; % Blue
    axes(handles.axes2);
    imshow(greenImage);



% --- Executes during object creation, after setting all properties.
function slider12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider13_Callback(hObject, eventdata, handles)
% hObject    handle to slider13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    global im
    if size(im, 3) == 1
        im = cat(3, im, im, im);
    end
    sliderValue = get(hObject, 'Value');
    minSaturation = 0;
    maxSaturation = 2.0;
    saturationAmount = minSaturation + (maxSaturation - minSaturation) * sliderValue;
    hsvImage = rgb2hsv(im); 
    hsvImage(:, :, 2) = hsvImage(:, :, 2) * saturationAmount;
    hsvImage(:, :, 2) = min(max(hsvImage(:, :, 2), 0), 1);
    saturatedImage = hsv2rgb(hsvImage);
    axes(handles.axes2);
    imshow(saturatedImage);


% --- Executes during object creation, after setting all properties.
function slider13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton79.
function pushbutton79_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton79 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
if size(im, 3) == 3
    gray_im = rgb2gray(im);
else
    gray_im = im;
end
bw_im = imbinarize(gray_im);
axes(handles.axes2);
imshow(bw_im);




% --- Executes on button press in pushbutton80.
function pushbutton80_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton80 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --- Push Button Callback функц ---
global im
if size(im, 3) == 3
    im_blurred = zeros(size(im), 'like', im); 
    h = fspecial('motion', 25, 45); 

    for i = 1:3
        im_blurred(:, :, i) = imfilter(im(:, :, i), h, 'replicate');
    end
else
    h = fspecial('motion', 25, 45); 
    im_blurred = imfilter(im, h, 'replicate');
end
axes(handles.axes2);
imshow(im_blurred);



% --- Executes on button press in pushbutton81.
function pushbutton81_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton81 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Read the image





% --- Executes on button press in pushbutton82.
function pushbutton82_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton82 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
complement_image = 255 - im;
axes(handles.axes2);
imshow(complement_image);


% --- Executes on button press in pushbutton83.
function pushbutton83_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton83 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global im
    if size(im, 3) == 3
        gray_im = rgb2gray(im);
    else
        gray_im = im;
    end
    eq_im = histeq(gray_im);
    axes(handles.axes2);
    imshow(eq_im);
  


% --- Executes on button press in pushbutton84.
function pushbutton84_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton84 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
flippedImage = flip(im, 2);  
axes(handles.axes2);
imshow(flippedImage);


% --- Executes on button press in pushbutton85.
function pushbutton85_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton85 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
flippedImage = flip(im, 1);  
axes(handles.axes2);
imshow(flippedImage);


% --- Executes on button press in pushbutton86.
function pushbutton86_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton86 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Read the image
global im
rotatedImage = rot90(im, -1);
axes(handles.axes2)
imshow(rotatedImage);


% --- Executes on button press in pushbutton87.
function pushbutton87_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton87 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global im
    persistent rotatedImage
    if isempty(rotatedImage)
        rotatedImage = im;
    end
    rotatedImage = imrotate(rotatedImage, 90, 'bilinear', 'crop');
    axes(handles.axes2);
    imshow(rotatedImage);


% --- Executes on button press in pushbutton88.
function pushbutton88_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton88 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global im
    padded_im = padarray(im, [50 50], 'replicate', 'both');
    axes(handles.axes2);
    imshow(padded_im);
  


% --- Executes on button press in pushbutton89.
function pushbutton89_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton89 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
if size(im, 3) == 3
    gray_im = rgb2gray(im);
else
    gray_im = im;
end
edge_im = edge(gray_im, 'Canny');
axes(handles.axes2);
imshow(edge_im);




% --- Executes on button press in pushbutton90.
function pushbutton90_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
noisyImage = imnoise(im, 'gaussian', 0, 0.01);
axes(handles.axes2);
imshow(noisyImage);


% --- Executes on button press in pushbutton92.
function pushbutton92_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton92 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
if size(im, 3) == 3
    gray_im = rgb2gray(im);
else
    gray_im = im;
end
axes(handles.axes2);
imhist(gray_im);
title('Image Histogram');
xlabel('Intensity Value');
ylabel('Pixel Count');


% --- Executes on button press in pushbutton94.
function pushbutton94_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton94 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global im
    I2=im2double(im);
    m=mean2(I2)
    E = 4;  
    im_double = im2double(im);
    contrast_im = 1./(1+(m./(I2+eps)).^4);	
    axes(handles.axes2);
    imshow(contrast_im);
    title('Contrast Adjusted (E = 4)');


% --- Executes on button press in pushbutton95.
function pushbutton95_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton95 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
  global im
    I2=im2double(im);
    m=mean2(I2)
    E = 6;
    im_double = im2double(im);
    contrast_im = 1./(1+(m./(I2+eps)).^6);
    axes(handles.axes2);
    imshow(contrast_im);
  


% --- Executes on button press in pushbutton96.
function pushbutton96_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton96 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
  global im
    I2=im2double(im);
    m=mean2(I2)
    E = 10; 
    im_double = im2double(im);
    contrast_im = 1./(1+(m./(I2+eps)).^10);	
    axes(handles.axes2);
    imshow(contrast_im);
  


% --- Executes on button press in pushbutton97.
function pushbutton97_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton97 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
  global im
    I2=im2double(im);
    m=mean2(I2)
    M = 0.5;  
    im_double = im2double(im);
    contrast_im = 1./(1+(0.5./(I2+eps)).^4);
    axes(handles.axes2);
    imshow(contrast_im);
  

% --- Executes on button press in pushbutton98.
function pushbutton98_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton98 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 global im
    I2=im2double(im);
    m=mean2(I2)
    M = 0.7;
    im_double = im2double(im);
    contrast_im = 1./(1+(0.7./(I2+eps)).^4);
    axes(handles.axes2);
    imshow(contrast_im);


% --- Executes on button press in pushbutton99.
function pushbutton99_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton99 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global im
    c = 1;
    I2 = im2double(im);
    log_im = 1 * log(1 + I2);
    axes(handles.axes2);
    imshow(log_im);

% --- Executes on button press in pushbutton100.
function pushbutton100_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton100 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
    c = 3;
    I2 = im2double(im);
    log_im = 3 * log(1 + I2);
    axes(handles.axes2);
    imshow(log_im);


% --- Executes on button press in pushbutton101.
function pushbutton101_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton101 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles    structure with handles and user data (see GUIDATA)
global im
    c = 5;
    I2 = im2double(im);
    log_im = 5 * log(1 + I2);
    axes(handles.axes2);
    imshow(log_im);


% --- Executes on button press in pushbutton106.
function pushbutton106_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton106 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
    noisy_im = imnoise(im, 'salt & pepper', 0.02); 
    axes(handles.axes2);
    imshow(noisy_im);



% --- Executes on button press in pushbutton107.
function pushbutton107_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton107 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
    sharp_im = imsharpen(im, 'Radius', 2, 'Amount', 1.5);
    axes(handles.axes2);
    imshow(sharp_im);

% --- Executes on button press in pushbutton108.
function pushbutton108_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton108 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
    map_custom=[1 1 1; 1 0 0; 0 0 0];
    im_custommap=dither(im,map_custom);
    axes(handles.axes2);
    imshow(im_custommap, map_custom);

% --- Executes on button press in pushbutton109.
function pushbutton109_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton109 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global im
    noisy_im = imnoise(im, 'speckle'); 
    axes(handles.axes2);
    imshow(noisy_im);


% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2


% --- Executes during object creation, after setting all properties.
function pushbutton106_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton106 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes on button press in pushbutton110.
function pushbutton110_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton110 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

image_data = getimage(handles.axes2);
% Save the image data to a file
imwrite(image_data, 'processed_image.png');
msgbox('Processed image saved!')
pause(1);
close();
