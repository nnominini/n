﻿namespace bd111
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.eemeg2 = new System.Windows.Forms.Button();
            this.bugj2 = new System.Windows.Forms.Button();
            this.buguivch2 = new System.Windows.Forms.Button();
            this.zuult2 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.aboutus2 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.eemeg2);
            this.groupBox2.Controls.Add(this.bugj2);
            this.groupBox2.Controls.Add(this.buguivch2);
            this.groupBox2.Controls.Add(this.zuult2);
            this.groupBox2.Controls.Add(this.button15);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.button16);
            this.groupBox2.Controls.Add(this.button17);
            this.groupBox2.Controls.Add(this.button18);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.panel12);
            this.groupBox2.Controls.Add(this.panel13);
            this.groupBox2.Controls.Add(this.panel14);
            this.groupBox2.Controls.Add(this.panel15);
            this.groupBox2.Controls.Add(this.panel16);
            this.groupBox2.Controls.Add(this.panel17);
            this.groupBox2.Controls.Add(this.panel18);
            this.groupBox2.Controls.Add(this.panel19);
            this.groupBox2.Controls.Add(this.panel20);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(633, 898);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            // 
            // eemeg2
            // 
            this.eemeg2.Location = new System.Drawing.Point(316, 104);
            this.eemeg2.Name = "eemeg2";
            this.eemeg2.Size = new System.Drawing.Size(75, 23);
            this.eemeg2.TabIndex = 27;
            this.eemeg2.Text = "Ээмэг";
            this.eemeg2.UseVisualStyleBackColor = true;
            // 
            // bugj2
            // 
            this.bugj2.Location = new System.Drawing.Point(222, 104);
            this.bugj2.Name = "bugj2";
            this.bugj2.Size = new System.Drawing.Size(75, 23);
            this.bugj2.TabIndex = 26;
            this.bugj2.Text = "Бөгж";
            this.bugj2.UseVisualStyleBackColor = true;
            // 
            // buguivch2
            // 
            this.buguivch2.Location = new System.Drawing.Point(130, 104);
            this.buguivch2.Name = "buguivch2";
            this.buguivch2.Size = new System.Drawing.Size(75, 23);
            this.buguivch2.TabIndex = 25;
            this.buguivch2.Text = "Бугуйвч";
            this.buguivch2.UseVisualStyleBackColor = true;
            // 
            // zuult2
            // 
            this.zuult2.Location = new System.Drawing.Point(37, 104);
            this.zuult2.Name = "zuult2";
            this.zuult2.Size = new System.Drawing.Size(75, 23);
            this.zuult2.TabIndex = 24;
            this.zuult2.Text = "Зүүлт";
            this.zuult2.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(464, 66);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(32, 22);
            this.button15.TabIndex = 22;
            this.button15.Text = "⌕";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(94, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(402, 22);
            this.textBox2.TabIndex = 21;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.DarkRed;
            this.button16.Location = new System.Drawing.Point(518, 58);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(40, 40);
            this.button16.TabIndex = 20;
            this.button16.Text = "❤️";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(573, 58);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(40, 40);
            this.button17.TabIndex = 19;
            this.button17.Text = "👤";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(37, 58);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(40, 40);
            this.button18.TabIndex = 18;
            this.button18.Text = "☰";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.DarkRed;
            this.label34.Location = new System.Drawing.Point(286, 44);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(70, 17);
            this.label34.TabIndex = 17;
            this.label34.Text = "since 2025";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Script MT Bold", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.DarkRed;
            this.label35.Location = new System.Drawing.Point(256, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(132, 44);
            this.label35.TabIndex = 16;
            this.label35.Text = "Annomi";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.OldLace;
            this.panel12.Controls.Add(this.aboutus2);
            this.panel12.Controls.Add(this.label37);
            this.panel12.Controls.Add(this.label38);
            this.panel12.Controls.Add(this.label39);
            this.panel12.Controls.Add(this.label40);
            this.panel12.Controls.Add(this.label41);
            this.panel12.Controls.Add(this.label42);
            this.panel12.Controls.Add(this.label43);
            this.panel12.Controls.Add(this.label44);
            this.panel12.Controls.Add(this.label45);
            this.panel12.Location = new System.Drawing.Point(37, 628);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(580, 142);
            this.panel12.TabIndex = 9;
            // 
            // aboutus2
            // 
            this.aboutus2.BackColor = System.Drawing.Color.OldLace;
            this.aboutus2.Location = new System.Drawing.Point(20, 88);
            this.aboutus2.Name = "aboutus2";
            this.aboutus2.Size = new System.Drawing.Size(130, 23);
            this.aboutus2.TabIndex = 29;
            this.aboutus2.Text = "Бидний тухай";
            this.aboutus2.UseVisualStyleBackColor = false;
            this.aboutus2.Click += new System.EventHandler(this.aboutus2_Click_1);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(235, 122);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(177, 16);
            this.label37.TabIndex = 28;
            this.label37.Text = "Khan-Uul district, 15th khoroo";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(201, 117);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(39, 22);
            this.label38.TabIndex = 27;
            this.label38.Text = "📍 ";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(235, 91);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(127, 16);
            this.label39.TabIndex = 26;
            this.label39.Text = "annomi@gmail.com";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(235, 57);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(63, 16);
            this.label40.TabIndex = 25;
            this.label40.Text = "99999999";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(201, 86);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(32, 22);
            this.label41.TabIndex = 24;
            this.label41.Text = "✉︎";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(201, 52);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(32, 22);
            this.label42.TabIndex = 23;
            this.label42.Text = "☎︎";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(201, 19);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(136, 20);
            this.label43.TabIndex = 22;
            this.label43.Text = "Холбоо барих";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.DarkRed;
            this.label44.Location = new System.Drawing.Point(42, 54);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(70, 17);
            this.label44.TabIndex = 21;
            this.label44.Text = "since 2025";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Script MT Bold", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.DarkRed;
            this.label45.Location = new System.Drawing.Point(12, 10);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(132, 44);
            this.label45.TabIndex = 20;
            this.label45.Text = "Annomi";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.OldLace;
            this.panel13.Controls.Add(this.pictureBox3);
            this.panel13.Controls.Add(this.label46);
            this.panel13.Controls.Add(this.label47);
            this.panel13.Location = new System.Drawing.Point(486, 366);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(130, 202);
            this.panel13.TabIndex = 8;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(110, 118);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(15, 168);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(52, 16);
            this.label46.TabIndex = 1;
            this.label46.Text = "180.00$";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(9, 142);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(93, 16);
            this.label47.TabIndex = 0;
            this.label47.Text = "Chain bracelet";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.OldLace;
            this.panel14.Controls.Add(this.pictureBox4);
            this.panel14.Controls.Add(this.label48);
            this.panel14.Controls.Add(this.label49);
            this.panel14.Location = new System.Drawing.Point(334, 366);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(130, 202);
            this.panel14.TabIndex = 7;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(9, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(110, 118);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 20;
            this.pictureBox4.TabStop = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 168);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(52, 16);
            this.label48.TabIndex = 1;
            this.label48.Text = "250.00$";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(6, 142);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(87, 16);
            this.label49.TabIndex = 0;
            this.label49.Text = "Heart to heart";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.OldLace;
            this.panel15.Controls.Add(this.pictureBox5);
            this.panel15.Controls.Add(this.label50);
            this.panel15.Controls.Add(this.label51);
            this.panel15.Location = new System.Drawing.Point(186, 366);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(129, 202);
            this.panel15.TabIndex = 6;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(8, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(110, 118);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 20;
            this.pictureBox5.TabStop = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(5, 168);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(45, 16);
            this.label50.TabIndex = 1;
            this.label50.Text = "55.00$";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(5, 142);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(95, 16);
            this.label51.TabIndex = 0;
            this.label51.Text = "Sparkling Ring";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.OldLace;
            this.panel16.Controls.Add(this.pictureBox10);
            this.panel16.Controls.Add(this.label52);
            this.panel16.Controls.Add(this.label53);
            this.panel16.Location = new System.Drawing.Point(37, 366);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(124, 202);
            this.panel16.TabIndex = 5;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(6, 12);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(110, 118);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 20;
            this.pictureBox10.TabStop = false;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(3, 168);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(52, 16);
            this.label52.TabIndex = 1;
            this.label52.Text = "105.00$";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(3, 142);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(93, 16);
            this.label53.TabIndex = 0;
            this.label53.Text = "Hoop earrings";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.OldLace;
            this.panel17.Controls.Add(this.pictureBox14);
            this.panel17.Controls.Add(this.label54);
            this.panel17.Controls.Add(this.label55);
            this.panel17.Location = new System.Drawing.Point(487, 145);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(130, 202);
            this.panel17.TabIndex = 7;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(11, 12);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(110, 118);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 21;
            this.pictureBox14.TabStop = false;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(15, 168);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(52, 16);
            this.label54.TabIndex = 1;
            this.label54.Text = "180.00$";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(9, 142);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(93, 16);
            this.label55.TabIndex = 0;
            this.label55.Text = "Chain bracelet";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.OldLace;
            this.panel18.Controls.Add(this.pictureBox13);
            this.panel18.Controls.Add(this.label56);
            this.panel18.Controls.Add(this.label57);
            this.panel18.Location = new System.Drawing.Point(334, 145);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(130, 202);
            this.panel18.TabIndex = 6;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(9, 12);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(110, 118);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 21;
            this.pictureBox13.TabStop = false;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(6, 168);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(52, 16);
            this.label56.TabIndex = 1;
            this.label56.Text = "250.00$";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(6, 142);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(87, 16);
            this.label57.TabIndex = 0;
            this.label57.Text = "Heart to heart";
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.OldLace;
            this.panel19.Controls.Add(this.pictureBox12);
            this.panel19.Controls.Add(this.label58);
            this.panel19.Controls.Add(this.label59);
            this.panel19.Location = new System.Drawing.Point(186, 145);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(129, 202);
            this.panel19.TabIndex = 5;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(9, 12);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(110, 118);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 21;
            this.pictureBox12.TabStop = false;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(5, 168);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(45, 16);
            this.label58.TabIndex = 1;
            this.label58.Text = "55.00$";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(5, 142);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(95, 16);
            this.label59.TabIndex = 0;
            this.label59.Text = "Sparkling Ring";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.OldLace;
            this.panel20.Controls.Add(this.pictureBox11);
            this.panel20.Controls.Add(this.label60);
            this.panel20.Controls.Add(this.label61);
            this.panel20.Location = new System.Drawing.Point(37, 145);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(124, 202);
            this.panel20.TabIndex = 4;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(6, 12);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(110, 118);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 21;
            this.pictureBox11.TabStop = false;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(3, 168);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(52, 16);
            this.label60.TabIndex = 1;
            this.label60.Text = "105.00$";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(3, 142);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(93, 16);
            this.label61.TabIndex = 0;
            this.label61.Text = "Hoop earrings";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(677, 920);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button eemeg2;
        private System.Windows.Forms.Button bugj2;
        private System.Windows.Forms.Button buguivch2;
        private System.Windows.Forms.Button zuult2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button aboutus2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
    }
}