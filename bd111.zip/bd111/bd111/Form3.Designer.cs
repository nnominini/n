﻿namespace bd111
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.eemeg3 = new System.Windows.Forms.Button();
            this.bugj3 = new System.Windows.Forms.Button();
            this.buguivch3 = new System.Windows.Forms.Button();
            this.zuult3 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.aboutus3 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox2.SuspendLayout();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.richTextBox1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.eemeg3);
            this.groupBox2.Controls.Add(this.bugj3);
            this.groupBox2.Controls.Add(this.buguivch3);
            this.groupBox2.Controls.Add(this.zuult3);
            this.groupBox2.Controls.Add(this.button15);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.button16);
            this.groupBox2.Controls.Add(this.button17);
            this.groupBox2.Controls.Add(this.button18);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.panel12);
            this.groupBox2.Location = new System.Drawing.Point(20, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(633, 770);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            // 
            // eemeg3
            // 
            this.eemeg3.Location = new System.Drawing.Point(316, 104);
            this.eemeg3.Name = "eemeg3";
            this.eemeg3.Size = new System.Drawing.Size(75, 23);
            this.eemeg3.TabIndex = 27;
            this.eemeg3.Text = "Ээмэг";
            this.eemeg3.UseVisualStyleBackColor = true;
            // 
            // bugj3
            // 
            this.bugj3.Location = new System.Drawing.Point(222, 104);
            this.bugj3.Name = "bugj3";
            this.bugj3.Size = new System.Drawing.Size(75, 23);
            this.bugj3.TabIndex = 26;
            this.bugj3.Text = "Бөгж";
            this.bugj3.UseVisualStyleBackColor = true;
            // 
            // buguivch3
            // 
            this.buguivch3.Location = new System.Drawing.Point(130, 104);
            this.buguivch3.Name = "buguivch3";
            this.buguivch3.Size = new System.Drawing.Size(75, 23);
            this.buguivch3.TabIndex = 25;
            this.buguivch3.Text = "Бугуйвч";
            this.buguivch3.UseVisualStyleBackColor = true;
            // 
            // zuult3
            // 
            this.zuult3.Location = new System.Drawing.Point(37, 104);
            this.zuult3.Name = "zuult3";
            this.zuult3.Size = new System.Drawing.Size(75, 23);
            this.zuult3.TabIndex = 24;
            this.zuult3.Text = "Зүүлт";
            this.zuult3.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(464, 66);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(32, 22);
            this.button15.TabIndex = 22;
            this.button15.Text = "⌕";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(94, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(402, 22);
            this.textBox2.TabIndex = 21;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.DarkRed;
            this.button16.Location = new System.Drawing.Point(518, 58);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(40, 40);
            this.button16.TabIndex = 20;
            this.button16.Text = "❤️";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(573, 58);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(40, 40);
            this.button17.TabIndex = 19;
            this.button17.Text = "👤";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(37, 58);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(40, 40);
            this.button18.TabIndex = 18;
            this.button18.Text = "☰";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.DarkRed;
            this.label34.Location = new System.Drawing.Point(286, 44);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(70, 17);
            this.label34.TabIndex = 17;
            this.label34.Text = "since 2025";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Script MT Bold", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.DarkRed;
            this.label35.Location = new System.Drawing.Point(256, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(132, 44);
            this.label35.TabIndex = 16;
            this.label35.Text = "Annomi";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.OldLace;
            this.panel12.Controls.Add(this.aboutus3);
            this.panel12.Controls.Add(this.label37);
            this.panel12.Controls.Add(this.label38);
            this.panel12.Controls.Add(this.label39);
            this.panel12.Controls.Add(this.label40);
            this.panel12.Controls.Add(this.label41);
            this.panel12.Controls.Add(this.label42);
            this.panel12.Controls.Add(this.label43);
            this.panel12.Controls.Add(this.label44);
            this.panel12.Controls.Add(this.label45);
            this.panel12.Location = new System.Drawing.Point(37, 614);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(576, 160);
            this.panel12.TabIndex = 9;
            // 
            // aboutus3
            // 
            this.aboutus3.BackColor = System.Drawing.Color.OldLace;
            this.aboutus3.Location = new System.Drawing.Point(14, 84);
            this.aboutus3.Name = "aboutus3";
            this.aboutus3.Size = new System.Drawing.Size(130, 23);
            this.aboutus3.TabIndex = 29;
            this.aboutus3.Text = "Бидний тухай";
            this.aboutus3.UseVisualStyleBackColor = false;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(235, 122);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(177, 16);
            this.label37.TabIndex = 28;
            this.label37.Text = "Khan-Uul district, 15th khoroo";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(201, 117);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(39, 22);
            this.label38.TabIndex = 27;
            this.label38.Text = "📍 ";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(235, 91);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(127, 16);
            this.label39.TabIndex = 26;
            this.label39.Text = "annomi@gmail.com";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(235, 57);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(63, 16);
            this.label40.TabIndex = 25;
            this.label40.Text = "99999999";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(201, 86);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(32, 22);
            this.label41.TabIndex = 24;
            this.label41.Text = "✉︎";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(201, 52);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(32, 22);
            this.label42.TabIndex = 23;
            this.label42.Text = "☎︎";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(201, 19);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(136, 20);
            this.label43.TabIndex = 22;
            this.label43.Text = "Холбоо барих";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.DarkRed;
            this.label44.Location = new System.Drawing.Point(42, 54);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(70, 17);
            this.label44.TabIndex = 21;
            this.label44.Text = "since 2025";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Script MT Bold", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.DarkRed;
            this.label45.Location = new System.Drawing.Point(12, 10);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(132, 44);
            this.label45.TabIndex = 20;
            this.label45.Text = "Annomi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Script MT Bold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(258, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 37);
            this.label1.TabIndex = 28;
            this.label1.Text = "About Us";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.OldLace;
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(37, 227);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(576, 368);
            this.richTextBox1.TabIndex = 29;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 769);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button eemeg3;
        private System.Windows.Forms.Button bugj3;
        private System.Windows.Forms.Button buguivch3;
        private System.Windows.Forms.Button zuult3;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button aboutus3;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}